from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class RecommendFeedbackCreate(BaseModel):
    restaurant_id: int  
    context: Optional[str] = "recommend_home"

class RecommendFeedbackOut(BaseModel):
    user_id: int         
    restaurant_id: int  
    context: Optional[str]
    timestamp: datetime

    class Config:
        from_attributes = True
