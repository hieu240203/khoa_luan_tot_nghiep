# from api.models.models import RecommendFeedback
# from sqlalchemy.orm import Session
# import uuid
# from datetime import datetime

# def log_recommend_click(db: Session, user_id: str, restaurant_id: str, context: str = ""):
#     record = RecommendFeedback(
#         id=str(uuid.uuid4()),
#         user_id=user_id,
#         restaurant_id=restaurant_id,
#         context=context,
#         timestamp=datetime.utcnow()
#     )
#     db.add(record)
#     db.commit()
#     db.refresh(record)
#     return record
from api.models.models import RecommendFeedback
from sqlalchemy.orm import Session
from datetime import datetime

def log_recommend_click(db: Session, user_id: int, restaurant_id: int, context: str = ""):
    record = RecommendFeedback(
        user_id=user_id,
        restaurant_id=restaurant_id,
        context=context,
        timestamp=datetime.utcnow()
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record
