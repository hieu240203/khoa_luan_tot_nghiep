from api.database.feedback_db import log_recommend_click
from sqlalchemy.orm import Session

def record_recommend_feedback(db: Session, user_id: int, restaurant_id: int, context: str):
    return log_recommend_click(db, user_id, restaurant_id, context)
