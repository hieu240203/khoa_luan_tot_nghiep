from sqlalchemy.orm import Session
from api.database.restaurant_db import search_restaurants
from api.database.restaurant_db import get_restaurant_by_id
from fastapi import HTTPException

# Dịch vụ tìm kiếm nhà hàng
def search_restaurant_service(
    db: Session,
    keyword: str = None,
    category: str = None,
    cuisine_style: str = None,
    city: str = None,
    district: str = None,
):
    return search_restaurants(
        db,
        keyword=keyword,
        category=category,
        cuisine_style=cuisine_style,
        city=city,
        district=district,
    )

# Dịch vụ lấy chi tiết nhà hàng
def get_restaurant_detail_service(db: Session, restaurant_id: int):
    restaurant = get_restaurant_by_id(db, restaurant_id)
    if not restaurant:
        raise HTTPException(status_code=404, detail="Restaurant not found")
    return restaurant
