# from sqlalchemy.orm import Session
# from api.schemas.review import ReviewCreate
# from api.models.models import Review, Restaurant
# from api.database.review_db import get_reviews_by_restaurant
# from datetime import datetime
# import uuid
# from fastapi import HTTPException
# from api.models.models import Review, User
# from api.schemas.review import ReviewOut
# from typing import List

# # Hàm tạo review mới
# def create_review_service(db: Session, user_id: str, data: ReviewCreate):
#     # Tạo review từ dữ liệu đầu vào
#     review = Review(
#         id=str(uuid.uuid4()),
#         user_id=user_id,
#         restaurant_id=data.restaurant_id,
#         comment=data.comment,
#         rating=data.rating,
#         images=data.images,
#         created_at=datetime.utcnow()
#     )
    
#     # Lưu review vào cơ sở dữ liệu
#     db.add(review)
    
#     # Cập nhật dữ liệu review vào restaurant (tăng total_reviews)
#     update_total_reviews(db, data.restaurant_id)

#     db.commit()
#     db.refresh(review)
    
#     return review  # Trả về review vừa tạo

# def get_reviews_for_restaurant_service(db: Session, restaurant_id: str) -> List[ReviewOut]:
#     reviews = db.query(Review).filter(Review.restaurant_id == restaurant_id).all()
#     results = []
#     for r in reviews:
#         user = db.query(User).filter(User.id == r.user_id).first()
#         results.append(ReviewOut(
#             id=r.id,
#             restaurant_id=r.restaurant_id,
#             user_id=r.user_id,
#             user_name=user.full_name if user else "Ẩn danh",  # ✅ Dùng tên user
#             rating=r.rating,
#             comment=r.comment,
#             images=r.images,
#             created_at=r.created_at,
#             reply=r.reply,
#             reply_by_user_id=r.reply_by_user_id,
#         ))
#     return results


# # Hàm trả lời bình luận (review)
# def reply_to_review(db: Session, review_id: str, reply_text: str, user_id: str):
#     # Lấy review cần trả lời
#     review = db.query(Review).filter(Review.id == review_id).first()
#     if not review:
#         raise HTTPException(status_code=404, detail="Review not found")

#     # Cập nhật trả lời cho review
#     review.reply = reply_text
#     review.reply_by_user_id = user_id
#     db.commit()
#     db.refresh(review)

#     return review
    

# # Hàm cập nhật số lượng bình luận (total_reviews) cho quán ăn
# def update_total_reviews(db: Session, restaurant_id: str):
#     restaurant = db.query(Restaurant).filter(Restaurant.id == restaurant_id).first()
#     if restaurant:
#         restaurant.total_reviews += 1
#         db.commit()
#     else:
#         raise HTTPException(status_code=404, detail="Restaurant not found")

# # Hàm tạo review và tăng total_reviews cho quán ăn (trong database)
# def create_review_db(db: Session, user_id: str, restaurant_id: str, comment: str, rating: float, images: str = None):
#     review = Review(
#         id=str(uuid.uuid4()),
#         user_id=user_id,
#         restaurant_id=restaurant_id,
#         comment=comment,
#         rating=rating,
#         images=images,
#         created_at=datetime.utcnow()
#     )
    
#     db.add(review)
    
#     # Tăng số lượng bình luận của quán ăn
#     update_total_reviews(db, restaurant_id)

#     db.commit()
#     db.refresh(review)
    
#     return review  # Trả về đối tượng review hợp lệ

from sqlalchemy.orm import Session
from api.schemas.review import ReviewCreate
from api.models.models import Review, Restaurant, User
from api.database.review_db import get_reviews_by_restaurant
from datetime import datetime
from fastapi import HTTPException
from api.schemas.review import ReviewOut
from typing import List

# Hàm tạo review mới
def create_review_service(db: Session, user_id: int, data: ReviewCreate):
    review = Review(
        user_id=user_id,
        restaurant_id=data.restaurant_id,
        comment=data.comment,
        rating=data.rating,
        images=data.images,
        created_at=datetime.utcnow()
    )
    
    db.add(review)
    update_total_reviews(db, data.restaurant_id)
    db.commit()
    db.refresh(review)
    
    return review

# Hàm lấy danh sách review theo nhà hàng
def get_reviews_for_restaurant_service(db: Session, restaurant_id: int) -> List[ReviewOut]:
    reviews = db.query(Review).filter(Review.restaurant_id == restaurant_id).all()
    results = []
    for r in reviews:
        user = db.query(User).filter(User.id == r.user_id).first()
        results.append(ReviewOut(
            id=r.id,
            restaurant_id=r.restaurant_id,
            user_id=r.user_id,
            user_name=user.full_name if user else "Ẩn danh",
            rating=r.rating,
            comment=r.comment,
            images=r.images,
            created_at=r.created_at,
            reply=r.reply,
            reply_by_user_id=r.reply_by_user_id,
        ))
    return results

# Hàm trả lời bình luận
def reply_to_review(db: Session, review_id: int, reply_text: str, user_id: int):
    review = db.query(Review).filter(Review.id == review_id).first()
    if not review:
        raise HTTPException(status_code=404, detail="Review not found")

    review.reply = reply_text
    review.reply_by_user_id = user_id
    db.commit()
    db.refresh(review)
    return review

# Cập nhật total_reviews cho nhà hàng
def update_total_reviews(db: Session, restaurant_id: int):
    restaurant = db.query(Restaurant).filter(Restaurant.id == restaurant_id).first()
    if restaurant:
        restaurant.total_reviews += 1
        db.commit()
    else:
        raise HTTPException(status_code=404, detail="Restaurant not found")

# Hàm tạo review từ dữ liệu thô
def create_review_db(db: Session, user_id: int, restaurant_id: int, comment: str, rating: float, images: str = None):
    review = Review(
        user_id=user_id,
        restaurant_id=restaurant_id,
        comment=comment,
        rating=rating,
        images=images,
        created_at=datetime.utcnow()
    )
    
    db.add(review)
    update_total_reviews(db, restaurant_id)
    db.commit()
    db.refresh(review)
    
    return review
