# from fastapi import APIRouter, Depends
# from sqlalchemy.orm import Session
# from dependencies import get_db
# from api.schemas.restaurant import RestaurantCreate, RestaurantUpdate
# from api.services.admin_service import (
#     create_restaurant_admin,
#     update_restaurant_admin,
#     delete_restaurant_admin
# )
# from api.models.models import Restaurant, Review, Favorite
# from typing import List

# router = APIRouter()

# @router.post("/", response_model=dict)
# def admin_create(data: RestaurantCreate, db: Session = Depends(get_db)):
#     return create_restaurant_admin(db, data)

# @router.put("/{restaurant_id}", response_model=dict)
# def admin_update(restaurant_id: str, data: RestaurantUpdate, db: Session = Depends(get_db)):
#     return update_restaurant_admin(db, restaurant_id, data)

# @router.delete("/{restaurant_id}", response_model=dict)
# def admin_delete(restaurant_id: str, db: Session = Depends(get_db)):
#     return delete_restaurant_admin(db, restaurant_id)

# @router.get("/stats", response_model=dict)
# def get_admin_stats(db: Session = Depends(get_db)):
#     return {
#         "total_restaurants": db.query(Restaurant).count(),
#         "total_reviews": db.query(Review).count(),
#         "total_favorites": db.query(Favorite).count()
#     }

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from dependencies import get_db, require_admin, get_current_admin
from api.schemas.restaurant import RestaurantCreate, RestaurantUpdate
from api.services.admin_service import (
    create_restaurant_admin,
    update_restaurant_admin,
    delete_restaurant_admin
)
from api.models.models import Restaurant, Review, Favorite, OwnerRequest, User
from typing import List
from api.models.models import User
from api.schemas.owner_request import OwnerRequestOut
from api.services import owner_request_service



router = APIRouter(prefix="/api/admin", tags=["Admin"])

@router.post("/", response_model=dict)
def admin_create(
    data: RestaurantCreate,
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin)
):
    return create_restaurant_admin(db, data)

@router.put("/{restaurant_id}", response_model=dict)
def admin_update(
    restaurant_id: int,
    data: RestaurantUpdate,
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin)
):
    return update_restaurant_admin(db, restaurant_id, data)

@router.delete("/{restaurant_id}", response_model=dict)
def admin_delete(
    restaurant_id: int,
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin)
):
    return delete_restaurant_admin(db, restaurant_id)

@router.get("/stats", response_model=dict)
def get_admin_stats(
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin)
):
    return {
        "total_restaurants": db.query(Restaurant).count(),
        "total_reviews": db.query(Review).count(),
        "total_favorites": db.query(Favorite).count()
    }

@router.get("/owner-requests", response_model=list[OwnerRequestOut])
def get_all_pending_requests(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_admin)  # hàm kiểm tra quyền admin
):
    return owner_request_service.get_pending_requests(db)

@router.post("/approve-owner/{request_id}")
def approve_owner(
    request_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_admin)
):
    return owner_request_service.approve_owner_request(db, request_id)