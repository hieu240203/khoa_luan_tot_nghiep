const BASE_URL = "http://127.0.0.1:8000/api"; // ✅ thêm /api chuẩn

function getToken() {
  return localStorage.getItem("token"); // ✅ đúng key
}

// Thêm nhà hàng vào yêu thích
export async function addFavoriteRestaurant(restaurant_id: string, token?: string) {
  const accessToken = token || getToken();
  if (!accessToken) throw new Error("Không có token, hãy đăng nhập.");

  const res = await fetch(`${BASE_URL}/favorites/`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${accessToken}`,
    },
    body: JSON.stringify({ restaurant_id }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({})); // phòng lỗi res không phải json
    throw new Error(err.detail || "Không thể thêm vào yêu thích");
  }

  return await res.json();
}

// Xoá nhà hàng khỏi yêu thích
export async function removeFavoriteRestaurant(restaurant_id: string, token?: string) {
  const accessToken = token || getToken();
  if (!accessToken) throw new Error("Không có token, hãy đăng nhập.");

  const res = await fetch(`${BASE_URL}/favorites/${restaurant_id}`, {
    method: "DELETE",
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!res.ok && res.status !== 204) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || "Không thể xóa khỏi yêu thích");
  }
}

// Lấy danh sách yêu thích và lấy thông tin chi tiết của nhà hàng
export async function getFavorites(token?: string) {
  const accessToken = token || getToken();
  if (!accessToken) throw new Error("Không có token, hãy đăng nhập.");

  const res = await fetch(`${BASE_URL}/favorites/`, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || "Không thể lấy danh sách yêu thích");
  }

  const favorites = await res.json();

  // Lấy thông tin chi tiết cho từng nhà hàng trong danh sách yêu thích
  const restaurants = await Promise.all(
    favorites.map(async (favorite: any) => {
      const restaurantRes = await fetch(`${BASE_URL}/restaurants/${favorite.restaurant_id}`);
      if (!restaurantRes.ok) {
        throw new Error("Không thể lấy thông tin nhà hàng");
      }
      return await restaurantRes.json();
    })
  );

  return restaurants;
}
