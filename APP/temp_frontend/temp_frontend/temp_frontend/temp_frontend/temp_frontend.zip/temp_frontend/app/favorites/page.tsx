"use client";

import { useState, useEffect } from "react";
import { getFavorites, removeFavoriteRestaurant } from "@/lib/favorite"; // Lấy API favorites
import { fetchRestaurantById } from "@/lib/api"; // Thêm API để lấy thông tin nhà hàng

export default function FavoritePage() {
  const [restaurants, setRestaurants] = useState<any[]>([]); // Lưu thông tin nhà hàng yêu thích
  const [favorites, setFavorites] = useState<any[]>([]); // Lưu danh sách các restaurant_id yêu thích

  useEffect(() => {
    async function fetchFavorites() {
      try {
        // Lấy danh sách các restaurant_id từ API favorites
        const favoriteList = await getFavorites();
        
        // Nếu không có danh sách yêu thích, trả về ngay
        if (!favoriteList || favoriteList.length === 0) {
          return;
        }

        // Lấy thông tin chi tiết của từng nhà hàng từ restaurant_id
        const restaurantsData = await Promise.all(
          favoriteList.map(async (favorite: any) => {
            // Gọi API lấy thông tin nhà hàng dựa trên restaurant_id
            return await fetchRestaurantById(favorite.restaurant_id);
          })
        );

        setRestaurants(restaurantsData); // Cập nhật thông tin các nhà hàng vào state
      } catch (error) {
        console.error("Lỗi khi lấy dữ liệu nhà hàng yêu thích:", error);
      }
    }

    fetchFavorites();
  }, []); // Chỉ gọi 1 lần khi component được mount

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-xl font-semibold mb-6">Danh sách nhà hàng yêu thích</h1>

      {restaurants.length === 0 ? (
        <p className="text-center text-gray-500">Không có nhà hàng yêu thích nào.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {restaurants.map((restaurant) => (
            <div
              key={restaurant.id}
              className="card bg-white shadow-lg rounded-lg overflow-hidden hover:shadow-xl transition-shadow"
            >
              {/* Hình ảnh nhà hàng */}
              <img
                src={restaurant.images || "/placeholder.svg"}
                alt={restaurant.name}
                className="w-full h-48 object-cover"
                style={{ objectFit: 'cover', maxHeight: '200px' }} // Giới hạn chiều cao ảnh
              />
              
              <div className="p-4">
                {/* Tên nhà hàng */}
                <h3 className="font-bold text-lg mb-2">{restaurant.name}</h3>
                
                {/* Địa chỉ nhà hàng */}
                <p className="text-gray-600 text-sm mb-2">{restaurant.address || "Chưa có địa chỉ"}</p>
                
                {/* Loại hình ẩm thực */}
                <p className="text-gray-500 text-sm mb-2">{restaurant.category || "Chưa có loại hình"}</p>
                
                {/* Đánh giá nhà hàng */}
                <div className="flex items-center mb-4">
                  <span className="text-green-600 font-semibold">
                    {restaurant.average_rating || "?/10"}
                  </span>
                </div>

                {/* Nút chi tiết */}
                <button className="text-green-600 hover:text-green-700">
                  <a href={`/restaurant/${restaurant.id}`}>Chi tiết</a>
                </button>

                {/* Nút xóa yêu thích */}
                <button
                  className="text-red-500 mt-2"
                  onClick={async () => {
                    try {
                      await removeFavoriteRestaurant(restaurant.id); // Xóa khỏi yêu thích
                      setRestaurants((prevRestaurants) =>
                        prevRestaurants.filter((item) => item.id !== restaurant.id)
                      ); // Cập nhật lại danh sách
                    } catch (error) {
                      console.error("Lỗi khi xóa nhà hàng yêu thích:", error);
                    }
                  }}
                >
                  Xóa khỏi yêu thích
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
