// import { MapPin, Clock, Phone, Globe, Share2, Heart, ChevronRight } from "lucide-react"
// import { Button } from "@/components/ui/button"
// import { Badge } from "@/components/ui/badge"
// import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
// import { Card, CardContent } from "@/components/ui/card"
// import { Separator } from "@/components/ui/separator"

// export default function RestaurantPage({ params }: { params: { id: string } }) {
//   // In a real app, you would fetch the restaurant data based on the ID
//   const restaurant = {
//     id: params.id,
//     name: "Nhà Hàng Xanh",
//     description:
//       "Nhà hàng chuyên về các món ăn Việt Nam truyền thống với không gian xanh mát, thân thiện với môi trường.",
//     images: [
//       "/placeholder.svg?height=500&width=800&text=Nhà+Hàng+Xanh+1",
//       "/placeholder.svg?height=500&width=800&text=Nhà+Hàng+Xanh+2",
//       "/placeholder.svg?height=500&width=800&text=Nhà+Hàng+Xanh+3",
//     ],
//     rating: 9.6,
//     reviewCount: 256,
//     priceRange: "$$",
//     location: "123 Đường Lê Lợi, Quận 1, TP.HCM",
//     phone: "028 1234 5678",
//     website: "www.nhahangxanh.com",
//     openHours: "08:00 - 22:00",
//     categories: ["Việt Nam", "Sang trọng", "Gia đình"],
//     menu: [
//       {
//         category: "Khai vị",
//         items: [
//           { name: "Gỏi cuốn tôm thịt", price: "85.000đ", image: "/placeholder.svg?height=100&width=100&text=Gỏi+cuốn" },
//           { name: "Chả giò hải sản", price: "95.000đ", image: "/placeholder.svg?height=100&width=100&text=Chả+giò" },
//           { name: "Salad trộn", price: "75.000đ", image: "/placeholder.svg?height=100&width=100&text=Salad" },
//         ],
//       },
//       {
//         category: "Món chính",
//         items: [
//           {
//             name: "Cơm chiên hải sản",
//             price: "150.000đ",
//             image: "/placeholder.svg?height=100&width=100&text=Cơm+chiên",
//           },
//           { name: "Bún chả Hà Nội", price: "120.000đ", image: "/placeholder.svg?height=100&width=100&text=Bún+chả" },
//           { name: "Phở bò tái", price: "110.000đ", image: "/placeholder.svg?height=100&width=100&text=Phở+bò" },
//         ],
//       },
//       {
//         category: "Tráng miệng",
//         items: [
//           { name: "Chè hạt sen", price: "45.000đ", image: "/placeholder.svg?height=100&width=100&text=Chè" },
//           { name: "Trái cây theo mùa", price: "65.000đ", image: "/placeholder.svg?height=100&width=100&text=Trái+cây" },
//         ],
//       },
//     ],
//     reviews: [
//       {
//         id: 1,
//         user: "Nguyễn Văn A",
//         avatar: "/placeholder.svg?height=50&width=50&text=NVA",
//         rating: 10,
//         date: "15/03/2023",
//         comment: "Đồ ăn ngon, không gian thoáng mát, nhân viên phục vụ nhiệt tình. Sẽ quay lại lần sau!",
//         images: ["/placeholder.svg?height=200&width=200&text=Review+1"],
//       },
//       {
//         id: 2,
//         user: "Trần Thị B",
//         avatar: "/placeholder.svg?height=50&width=50&text=TTB",
//         rating: 8,
//         date: "02/04/2023",
//         comment: "Món ăn ngon, giá cả hợp lý. Tuy nhiên, thời gian phục vụ hơi lâu vào giờ cao điểm.",
//         images: [],
//       },
//     ],
//   }

//   return (
//     <div className="container mx-auto px-4 py-8">
//       {/* Restaurant Header */}
//       <div className="flex flex-col md:flex-row gap-6 mb-8">
//         <div className="w-full md:w-2/3">
//           <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden">
//             <img
//               src={restaurant.images[0] || "/placeholder.svg"}
//               alt={restaurant.name}
//               className="w-full h-full object-cover"
//             />
//             <div className="absolute bottom-4 right-4 flex gap-2">
//               <Button variant="outline" size="icon" className="bg-white/90 hover:bg-white">
//                 <Heart className="h-5 w-5" />
//               </Button>
//               <Button variant="outline" size="icon" className="bg-white/90 hover:bg-white">
//                 <Share2 className="h-5 w-5" />
//               </Button>
//             </div>
//           </div>
//           <div className="flex gap-2 mt-3">
//             {restaurant.images.slice(1, 4).map((image, index) => (
//               <div key={index} className="w-1/3 h-24 rounded-lg overflow-hidden">
//                 <img
//                   src={image || "/placeholder.svg"}
//                   alt={`${restaurant.name} ${index + 2}`}
//                   className="w-full h-full object-cover"
//                 />
//               </div>
//             ))}
//           </div>
//         </div>
//         <div className="w-full md:w-1/3">
//           <Card>
//             <CardContent className="p-6">
//               <div className="space-y-4">
//                 <div>
//                   <h1 className="text-2xl font-bold">{restaurant.name}</h1>
//                   <div className="flex items-center mt-2">
//                     <div className="flex items-center">
//                       <span className="font-medium">{restaurant.rating}/10</span>
//                       <span className="ml-1 text-gray-500">({restaurant.reviewCount} đánh giá)</span>
//                     </div>
//                     <span className="mx-2 text-gray-300">•</span>
//                     <span className="text-gray-500">{restaurant.priceRange}</span>
//                   </div>
//                   <div className="flex flex-wrap gap-2 mt-2">
//                     {restaurant.categories.map((category, index) => (
//                       <Badge key={index} variant="outline" className="bg-gray-50">
//                         {category}
//                       </Badge>
//                     ))}
//                   </div>
//                 </div>
//                 <Separator />
//                 <div className="space-y-3">
//                   <div className="flex items-start">
//                     <MapPin className="h-5 w-5 text-gray-500 mr-3 mt-0.5" />
//                     <div>
//                       <p className="text-sm font-medium">Địa chỉ</p>
//                       <p className="text-sm text-gray-500">{restaurant.location}</p>
//                     </div>
//                   </div>
//                   <div className="flex items-start">
//                     <Clock className="h-5 w-5 text-gray-500 mr-3 mt-0.5" />
//                     <div>
//                       <p className="text-sm font-medium">Giờ mở cửa</p>
//                       <p className="text-sm text-gray-500">{restaurant.openHours}</p>
//                     </div>
//                   </div>
//                   <div className="flex items-start">
//                     <Phone className="h-5 w-5 text-gray-500 mr-3 mt-0.5" />
//                     <div>
//                       <p className="text-sm font-medium">Điện thoại</p>
//                       <p className="text-sm text-gray-500">{restaurant.phone}</p>
//                     </div>
//                   </div>
//                   <div className="flex items-start">
//                     <Globe className="h-5 w-5 text-gray-500 mr-3 mt-0.5" />
//                     <div>
//                       <p className="text-sm font-medium">Website</p>
//                       <p className="text-sm text-gray-500">{restaurant.website}</p>
//                     </div>
//                   </div>
//                 </div>
//                 <Separator />
//                 <div className="flex flex-col gap-3">
//                   <Button className="w-full bg-green-600 hover:bg-green-700">Đặt bàn</Button>
//                   <Button variant="outline" className="w-full">
//                     Xem bản đồ
//                   </Button>
//                 </div>
//               </div>
//             </CardContent>
//           </Card>
//         </div>
//       </div>

//       {/* Restaurant Content */}
//       <Tabs defaultValue="menu" className="w-full">
//         <TabsList className="w-full justify-start mb-6 bg-transparent border-b rounded-none h-auto p-0">
//           <TabsTrigger
//             value="menu"
//             className="rounded-none border-b-2 border-transparent data-[state=active]:border-green-600 data-[state=active]:bg-transparent px-4 py-2"
//           >
//             Thực đơn
//           </TabsTrigger>
//           <TabsTrigger
//             value="reviews"
//             className="rounded-none border-b-2 border-transparent data-[state=active]:border-green-600 data-[state=active]:bg-transparent px-4 py-2"
//           >
//             Đánh giá ({restaurant.reviewCount})
//           </TabsTrigger>
//           <TabsTrigger
//             value="about"
//             className="rounded-none border-b-2 border-transparent data-[state=active]:border-green-600 data-[state=active]:bg-transparent px-4 py-2"
//           >
//             Giới thiệu
//           </TabsTrigger>
//         </TabsList>
//         <TabsContent value="menu" className="mt-0">
//           <div className="space-y-8">
//             {restaurant.menu.map((category, index) => (
//               <div key={index}>
//                 <h2 className="text-xl font-bold mb-4">{category.category}</h2>
//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
//                   {category.items.map((item, itemIndex) => (
//                     <div key={itemIndex} className="flex items-center gap-4 p-3 rounded-lg hover:bg-gray-50">
//                       <img
//                         src={item.image || "/placeholder.svg"}
//                         alt={item.name}
//                         className="w-16 h-16 rounded-md object-cover"
//                       />
//                       <div className="flex-1">
//                         <h3 className="font-medium">{item.name}</h3>
//                         <p className="text-green-600 font-medium">{item.price}</p>
//                       </div>
//                     </div>
//                   ))}
//                 </div>
//               </div>
//             ))}
//           </div>
//         </TabsContent>
//         <TabsContent value="reviews" className="mt-0">
//           <div className="space-y-6">
//             <div className="flex items-center justify-between">
//               <h2 className="text-xl font-bold">Đánh giá từ khách hàng</h2>
//               <Button className="bg-green-600 hover:bg-green-700">Viết đánh giá</Button>
//             </div>
//             <div className="space-y-6">
//               {restaurant.reviews.map((review) => (
//                 <div key={review.id} className="border rounded-lg p-4">
//                   <div className="flex items-start gap-3">
//                     <img
//                       src={review.avatar || "/placeholder.svg"}
//                       alt={review.user}
//                       className="w-10 h-10 rounded-full"
//                     />
//                     <div className="flex-1">
//                       <div className="flex items-center justify-between">
//                         <h3 className="font-medium">{review.user}</h3>
//                         <span className="text-sm text-gray-500">{review.date}</span>
//                       </div>
//                       <div className="flex items-center mt-1">
//                         <span className="font-medium">{review.rating}/10</span>
//                       </div>
//                       <p className="mt-2 text-gray-700">{review.comment}</p>
//                       {review.images.length > 0 && (
//                         <div className="flex gap-2 mt-3">
//                           {review.images.map((image, index) => (
//                             <img
//                               key={index}
//                               src={image || "/placeholder.svg"}
//                               alt={`Review image ${index + 1}`}
//                               className="w-20 h-20 rounded-md object-cover"
//                             />
//                           ))}
//                         </div>
//                       )}
//                     </div>
//                   </div>
//                 </div>
//               ))}
//             </div>
//             <div className="text-center">
//               <Button variant="outline" className="mt-4">
//                 Xem thêm đánh giá <ChevronRight className="ml-1 h-4 w-4" />
//               </Button>
//             </div>
//           </div>
//         </TabsContent>
//         <TabsContent value="about" className="mt-0">
//           <div className="space-y-6">
//             <div>
//               <h2 className="text-xl font-bold mb-3">Giới thiệu</h2>
//               <p className="text-gray-700">{restaurant.description}</p>
//             </div>
//             <div>
//               <h2 className="text-xl font-bold mb-3">Không gian</h2>
//               <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
//                 {restaurant.images.map((image, index) => (
//                   <div key={index} className="rounded-lg overflow-hidden h-48">
//                     <img
//                       src={image || "/placeholder.svg"}
//                       alt={`${restaurant.name} space ${index + 1}`}
//                       className="w-full h-full object-cover"
//                     />
//                   </div>
//                 ))}
//               </div>
//             </div>
//           </div>
//         </TabsContent>
//       </Tabs>
//     </div>
//   )
// }

"use client"

import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import {
  MapPin,
  Clock,
  Phone,
  Globe,
  Share2,
  Heart,
  ChevronRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"

export default function RestaurantPage() {
  const params = useParams()
  const [restaurant, setRestaurant] = useState<any>(null)

  useEffect(() => {
    async function fetchData() {
      try {
        const res = await fetch(`http://localhost:8000/api/restaurants/${params.id}`)
        const data = await res.json()
        setRestaurant(data)
      } catch (error) {
        console.error("Lỗi khi lấy dữ liệu nhà hàng:", error)
      }
    }

    fetchData()
  }, [params.id])

  if (!restaurant) {
    return <div className="text-center py-10">Đang tải dữ liệu nhà hàng...</div>
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Restaurant Header */}
      <div className="flex flex-col md:flex-row gap-6 mb-8">
        <div className="w-full md:w-2/3">
          {/* Ảnh lớn */}
          <div className="aspect-video w-full overflow-hidden rounded-lg shadow">
            <img
              src={restaurant.images || "/placeholder.svg"}
              alt={restaurant.name}
              className="object-cover w-full h-full"
            />
          </div>
          {/* Các ảnh nhỏ (nếu bạn có) */}
          {/* Có thể thêm gallery sau */}
        </div>

        <div className="w-full md:w-1/3">
          <Card>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div>
                  <h1 className="text-2xl font-bold">{restaurant.name}</h1>
                  <div className="flex items-center mt-2">
                    <span className="font-medium">{restaurant.average_rating}/10</span>
                    <span className="ml-1 text-gray-500">
                      ({restaurant.total_reviews} đánh giá)
                    </span>
                    <span className="mx-2 text-gray-300">•</span>
                    <span className="text-gray-500">{restaurant.price_range}</span>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    <Badge variant="outline" className="bg-gray-50">{restaurant.category}</Badge>
                    <Badge variant="outline" className="bg-gray-50">{restaurant.cuisine_style}</Badge>
                  </div>
                </div>
                <Separator />
                <div className="space-y-3">
                  <div className="flex items-start">
                    <MapPin className="h-5 w-5 text-gray-500 mr-3 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium">Địa chỉ</p>
                      <p className="text-sm text-gray-500">{restaurant.address}</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <Clock className="h-5 w-5 text-gray-500 mr-3 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium">Giờ mở cửa</p>
                      <p className="text-sm text-gray-500">{restaurant.opening_hours}</p>
                    </div>
                  </div>
                  {/* Nếu có số điện thoại, website có thể bổ sung */}
                </div>
                <Separator />
                <div className="flex flex-col gap-3">
                  <Button className="w-full bg-green-600 hover:bg-green-700">Đặt bàn</Button>
                  <Button variant="outline" className="w-full">
                    Xem bản đồ
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Tabs Giới thiệu, Đánh giá, Menu */}
      <Tabs defaultValue="about" className="w-full">
        <TabsList className="w-full justify-start mb-6 bg-transparent border-b rounded-none h-auto p-0">
          <TabsTrigger value="about" className="px-4 py-2 rounded-none border-b-2 border-transparent data-[state=active]:border-green-600 data-[state=active]:bg-transparent">
            Giới thiệu
          </TabsTrigger>
          {/* Bạn có thể bật thêm Tabs: reviews, menu nếu có API */}
        </TabsList>

        <TabsContent value="about" className="mt-0">
          <h2 className="text-xl font-bold mb-3">Giới thiệu</h2>
          <p className="text-gray-700">{restaurant.description || "Chưa có mô tả."}</p>
        </TabsContent>
      </Tabs>
    </div>
  )
}
